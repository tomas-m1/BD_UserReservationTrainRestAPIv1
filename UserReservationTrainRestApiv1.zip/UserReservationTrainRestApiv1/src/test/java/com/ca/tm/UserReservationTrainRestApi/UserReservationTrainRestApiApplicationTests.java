package com.ca.tm.UserReservationTrainRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserReservationTrainRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
