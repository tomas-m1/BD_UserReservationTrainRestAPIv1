package com.ca.tm.UserReservationTrainRestApi.controllers;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.services.ReservationService;
import com.ca.tm.UserReservationTrainRestApi.services.TrainService;
import com.ca.tm.UserReservationTrainRestApi.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;

    @GetMapping
    public List<Reservation> getAllReservations() {
        return reservationService.getAllReservations();
    }
    @GetMapping("/{id}")
    public Reservation getReservationById(@PathVariable Long id) {
        return reservationService.getReservationById(id);
    }
    @PostMapping
    public void createReservation(@RequestBody Reservation reservation) {
        reservationService.createReservation(reservation);
    }
    @PutMapping("/{id}")
    public void updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
        reservationService.updateReservation(id, reservation);
    }
    @DeleteMapping("/{id}")
    public void deleteReservation(@PathVariable Long id) {
        reservationService.deleteReservation(id);
    }


//    @RequestMapping(method = RequestMethod.GET, value = "/reservations")
//    public List<Reservation> getAllReservations() {
//        return reservationService.getAllReservations();
//    }
//    @RequestMapping(method = RequestMethod.GET, value = "/reservations/{id}")
//    public Reservation getReservationById(@PathVariable Long id) {
//        return reservationService.getReservationById(id);
//    }
//    @RequestMapping(method = RequestMethod.POST, value = "/reservations")
//    public void createReservation(@RequestBody Reservation reservation) {
//        reservationService.createReservation(reservation);
//    }
//    @RequestMapping(method = RequestMethod.PUT, value = "/reservations/{id}")
//    public void updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
//        reservationService.updateReservation(id, reservation);
//    }
//    @RequestMapping(method = RequestMethod.DELETE, value = "/reservations/{id}")
//    public void deleteReservation(@PathVariable Long id) {
//        reservationService.deleteReservation(id);
//    }
}