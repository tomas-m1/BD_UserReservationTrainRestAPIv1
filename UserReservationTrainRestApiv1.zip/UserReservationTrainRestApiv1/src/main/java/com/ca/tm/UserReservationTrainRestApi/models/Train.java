package com.ca.tm.UserReservationTrainRestApi.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "trains")
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String trainName;

    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "trains")
    @JsonIgnore // Ignore the reservations field during serialization
    private List<Reservation> reservations;

    public Train(String trainName) {
        this.trainName = trainName;
        this.reservations = new ArrayList<>();
    }

    @Override
    public String toString() {
        return "Train{" +
                "id=" + id +
                ", trainName='" + trainName + '\'' +
                ", reservations=" + reservations +
                '}';
    }
}
