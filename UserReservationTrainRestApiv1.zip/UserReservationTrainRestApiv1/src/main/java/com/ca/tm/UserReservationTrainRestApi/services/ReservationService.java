package com.ca.tm.UserReservationTrainRestApi.services;

import com.ca.tm.UserReservationTrainRestApi.exceptions.RecordNotFoundException;
import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.repositories.ReservationRepository;
import com.ca.tm.UserReservationTrainRestApi.repositories.TrainRepository;
import com.ca.tm.UserReservationTrainRestApi.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TrainRepository trainRepository;

    public List<Reservation> getAllReservations() {
        return (List<Reservation>) reservationRepository.findAll();
    }
    public Reservation getReservationById(Long id) {
        return reservationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reservation not found"));
    }
    public void createReservation(Reservation reservation) {
        reservationRepository.save(reservation);
    }
    public void updateReservation(Long id, Reservation reservation) {
        Reservation existingReservation = reservationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reservation not found"));
        existingReservation.setId(reservation.getId());
        existingReservation.setUser(reservation.getUser());
        existingReservation.setFromLocation(reservation.getFromLocation());
        existingReservation.setToLocation(reservation.getToLocation());
        existingReservation.setTrains(reservation.getTrains());
        reservationRepository.save(existingReservation);
    }
    public void deleteReservation(Long id) {
        Reservation existingReservation = reservationRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Reservation not found"));
        reservationRepository.delete(existingReservation);
    }
}