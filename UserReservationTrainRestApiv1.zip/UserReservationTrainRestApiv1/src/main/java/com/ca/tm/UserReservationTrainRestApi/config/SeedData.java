package com.ca.tm.UserReservationTrainRestApi.config;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.services.ReservationService;
import com.ca.tm.UserReservationTrainRestApi.services.TrainService;
import com.ca.tm.UserReservationTrainRestApi.services.UserService;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@NoArgsConstructor
@Component
public class SeedData implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private TrainService trainService;

    @Override
    public void run(String... args) throws Exception {

        User user1 = new User("John Doe");
        User user2 = new User("Jane Smith");
        User user3 = new User("Evans Fourier");
        User user4 = new User("Daniel Leroux");
        User user5 = new User("Mario Lemieux");
        User user6 = new User("Andry Walter");
        User user7 = new User("Hans Sjostrom");
        userService.createUser(user1);
        userService.createUser(user2);
        userService.createUser(user3);
        userService.createUser(user4);
        userService.createUser(user5);
        userService.createUser(user6);
        userService.createUser(user7);

        Train train1 = new Train("SNCF Express 450");
        Train train2 = new Train("SNCF Express 420");
        Train train3 = new Train("SNCF Local 150");
        Train train4 = new Train("TGV Express 480");
        Train train5 = new Train("TGV Express 495");
        Train train6 = new Train("RER Local 155");
        Train train7 = new Train("EuroStar Express 320");
        Train train8 = new Train("Arlanda Express 320");
        Train train9 = new Train("SJ High-Speed 220");
        Train train10 = new Train("SJ High-Speed X2 230");
        Train train11 = new Train("SJ Intercity Train 150");
        Train train12 = new Train("SJ Regional Train 155");

        trainService.createTrain(train1);
        trainService.createTrain(train2);
        trainService.createTrain(train3);
        trainService.createTrain(train4);
        trainService.createTrain(train5);
        trainService.createTrain(train6);
        trainService.createTrain(train7);
        trainService.createTrain(train8);
        trainService.createTrain(train9);
        trainService.createTrain(train10);
        trainService.createTrain(train11);
        trainService.createTrain(train12);

        List<Train> trainList1 = Arrays.asList(train1, train2, train5);
        List<Train> trainList2 = Arrays.asList(train1, train3);
        List<Train> trainList3 = Arrays.asList(train3, train4);
        List<Train> trainList4 = Arrays.asList(train4, train5);
        List<Train> trainList5 = Arrays.asList(train5,train1);
        List<Train> trainList6 = Arrays.asList(train7, train3);
        List<Train> trainList7 = Arrays.asList(train6, train7);
        List<Train> trainList8 = Arrays.asList(train2, train6);
        List<Train> trainList9 = Arrays.asList(train8, train9);
        List<Train> trainList10 = Arrays.asList(train9, train10);
        List<Train> trainList11 = Arrays.asList(train11);
        List<Train> trainList12 = Arrays.asList(train12);


        Reservation reservation1 = new Reservation(user1, "Paris", "Bratislava", trainList1);
        Reservation reservation2 = new Reservation(user1, "Paris", "Berlin", trainList2);
        Reservation reservation3 = new Reservation(user2, "Lion", "Paris", trainList3);
        Reservation reservation4 = new Reservation(user3, "London", "Manchester", trainList6);
        Reservation reservation5 = new Reservation(user4, "London", "Glasgow", trainList7);
        Reservation reservation6 = new Reservation(user4, "Berlin", "Paris", trainList2);
        Reservation reservation7 = new Reservation(user5, "Paris", "Amsterdam", trainList8);
        Reservation reservation8 = new Reservation(user5, "Prague", "Paris", trainList4);
        Reservation reservation9 = new Reservation(user6, "Paris", "Prague", trainList5);
        Reservation reservation10 = new Reservation(user7, "Stockholm", "Arlanda", trainList4);
        Reservation reservation11 = new Reservation(user7, "Stockholm", "Oslo", trainList9);
        Reservation reservation12 = new Reservation(user7, "Stockholm", "Copenhagen", trainList10);
        Reservation reservation13 = new Reservation(user7, "Vasteras", "Malmo", trainList11);
        Reservation reservation14 = new Reservation(user7, "Orebro", "Gothenburg", trainList12);


        reservationService.createReservation(reservation1);
        reservationService.createReservation(reservation2);
        reservationService.createReservation(reservation3);
        reservationService.createReservation(reservation4);
        reservationService.createReservation(reservation5);
        reservationService.createReservation(reservation6);
        reservationService.createReservation(reservation7);
        reservationService.createReservation(reservation8);
        reservationService.createReservation(reservation9);
        reservationService.createReservation(reservation10);
        reservationService.createReservation(reservation11);
        reservationService.createReservation(reservation12);
        reservationService.createReservation(reservation13);
        reservationService.createReservation(reservation14);


    }
}

