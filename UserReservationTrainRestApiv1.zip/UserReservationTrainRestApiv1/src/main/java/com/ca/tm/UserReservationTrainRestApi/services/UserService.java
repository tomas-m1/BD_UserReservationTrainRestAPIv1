package com.ca.tm.UserReservationTrainRestApi.services;

import com.ca.tm.UserReservationTrainRestApi.exceptions.RecordNotFoundException;
import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    public List<User> getAllUsers() {
        return (List<User>) userRepository.findAll();
    }
    public User getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("User not found"));
    }
    public void createUser(User user) {
        userRepository.save(user);
    }
    public void updateUser(Long id, User user) {
        User existingUser = userRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("User not found"));
        existingUser.setId(user.getId());
        existingUser.setName(user.getName());
        existingUser.setReservations(user.getReservations());
        userRepository.save(existingUser);
    }
    public void deleteUser(Long id) {
        User existingUser = userRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("User not found"));
        userRepository.delete(existingUser);
    }
}