package com.ca.tm.UserReservationTrainRestApi.controllers;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.services.ReservationService;
import com.ca.tm.UserReservationTrainRestApi.services.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trains")
public class TrainController {
    @Autowired
    private TrainService trainService;

    @GetMapping
    public List<Train> getAllTrains() {
        return trainService.getAllTrains();
    }
    @GetMapping("/{id}")
    public Train getTrainById(@PathVariable Long id) {
        return trainService.getTrainById(id);
    }
    @PostMapping
    public void createTrain(@RequestBody Train train) {
        trainService.createTrain(train);
    }
    @PutMapping("/{id}")
    public void updateTrain(@PathVariable Long id, @RequestBody Train train) {
        trainService.updateTrain(id, train);
    }
    @DeleteMapping("/{id}")
    public void deleteTrain(@PathVariable Long id) {
        trainService.deleteTrain(id);
    }

//    @RequestMapping(method = RequestMethod.GET, value = "/trains")
//    public List<Train> getAllTrains() {
//        return trainService.getAllTrains();
//    }
//    @RequestMapping(method = RequestMethod.GET, value = "/trains/{id}")
//    public Train getTrainById(@PathVariable Long id) {
//        return trainService.getTrainById(id);
//    }
//    @RequestMapping(method = RequestMethod.POST, value = "/trains")
//    public void createTrain(@RequestBody Train train) {
//        trainService.createTrain(train);
//    }
//    @RequestMapping(method = RequestMethod.PUT, value = "/trains/{id}")
//    public void updateTrain(@PathVariable Long id, @RequestBody Train train) {
//        trainService.updateTrain(id, train);
//    }
//    @RequestMapping(method = RequestMethod.DELETE, value = "/trains/{id}")
//    public void deleteTrain(@PathVariable Long id) {
//        trainService.deleteTrain(id);
//    }
}