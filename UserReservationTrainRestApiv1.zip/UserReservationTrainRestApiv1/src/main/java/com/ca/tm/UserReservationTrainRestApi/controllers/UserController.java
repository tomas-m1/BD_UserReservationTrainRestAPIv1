package com.ca.tm.UserReservationTrainRestApi.controllers;

import com.ca.tm.UserReservationTrainRestApi.models.Reservation;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.repositories.UserRepository;
import com.ca.tm.UserReservationTrainRestApi.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }
    @PostMapping
    public void createUser(@RequestBody User user) {
        userService.createUser(user);
    }
    @PutMapping("/{id}")
    public void updateUser(@PathVariable Long id, @RequestBody User user) {
        userService.updateUser(id, user);
    }
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

//    @RequestMapping(method = RequestMethod.GET, value = "/users")
//    public List<User> getAllUsers() {
//        return userService.getAllUsers();
//    }
//    @RequestMapping(method = RequestMethod.GET, value = "/users/{id}")
//    public User getUserById(@PathVariable Long id) {
//        return userService.getUserById(id);
//    }

//    @RequestMapping(method = RequestMethod.POST, value = "/users")
//    public void createUser(@RequestBody User user) {
//        userService.createUser(user);
//    }

//    @RequestMapping(method = RequestMethod.PUT, value = "/users/{id}")
//    public void updateUser(@PathVariable Long id, @RequestBody User user) {
//        userService.updateUser(id, user);
//    }
//    @RequestMapping(method = RequestMethod.DELETE, value = "/users/{id}")
//    public void deleteUser(@PathVariable Long id) {
//        userService.deleteUser(id);
//    }
}