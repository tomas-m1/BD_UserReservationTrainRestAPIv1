package com.ca.tm.UserReservationTrainRestApi.services;

import com.ca.tm.UserReservationTrainRestApi.exceptions.RecordNotFoundException;
import com.ca.tm.UserReservationTrainRestApi.models.Train;
import com.ca.tm.UserReservationTrainRestApi.models.User;
import com.ca.tm.UserReservationTrainRestApi.repositories.ReservationRepository;
import com.ca.tm.UserReservationTrainRestApi.repositories.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrainService {
    @Autowired
    private TrainRepository trainRepository;

    @Autowired
    private ReservationRepository reservationRepository;
    public List<Train> getAllTrains() {
        return (List<Train>) trainRepository.findAll();
    }
    public Train getTrainById(Long id) {
        return trainRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Train not found"));
    }
    public void createTrain(Train train) {
        trainRepository.save(train);
    }
    public void updateTrain(Long id, Train train) {
        Train existingTrain = trainRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Train not found"));
        existingTrain.setId(train.getId());
        existingTrain.setTrainName(train.getTrainName());
        existingTrain.setReservations(train.getReservations());
        trainRepository.save(existingTrain);
    }
    public void deleteTrain(Long id) {
        Train existingTrain = trainRepository.findById(id).orElseThrow(() -> new RecordNotFoundException("Train not found"));
        trainRepository.delete(existingTrain);
    }
}